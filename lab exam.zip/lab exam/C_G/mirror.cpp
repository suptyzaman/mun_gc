#include <graphics.h>
#include <iostream>
using namespace std;

// Function to draw a triangle
void drawTriangle(int x1, int y1, int x2, int y2, int x3, int y3, int color) {
    setcolor(color);
    line(x1, y1, x2, y2);
    line(x2, y2, x3, y3);
    line(x3, y3, x1, y1);
}

int main() {
    // Initialize graphics
    int gd = DETECT, gm;
    initgraph(&gd, &gm, (char*)"");

    // Original triangle vertices
    int x1 = 100, y1 = 150;
    int x2 = 200, y2 = 150;
    int x3 = 150, y3 = 50;

    // Get screen dimensions for mirroring
    int maxX = getmaxx();  // Maximum X-coordinate
    int maxY = getmaxy();  // Maximum Y-coordinate

    // Draw the original triangle
    drawTriangle(x1, y1, x2, y2, x3, y3, WHITE);
    outtextxy(x1, y1, (char*)"Original");

    // Ask the user for mirroring option
    int option;
    cout << "Choose the mirroring operation:" << endl;
    cout << "1. Mirror along X-axis" << endl;
    cout << "2. Mirror along Y-axis" << endl;
    cout << "3. Mirror along both axes" << endl;
    cout << "Enter your choice (1/2/3): ";
    cin >> option;

    // Perform the mirroring based on user choice
    if (option == 1) {
        // Mirror across the X-axis
        int x1_mirroredX = x1;
        int y1_mirroredX = maxY - y1;
        int x2_mirroredX = x2;
        int y2_mirroredX = maxY - y2;
        int x3_mirroredX = x3;
        int y3_mirroredX = maxY - y3;

        drawTriangle(x1_mirroredX, y1_mirroredX, x2_mirroredX, y2_mirroredX, x3_mirroredX, y3_mirroredX, YELLOW);
        outtextxy(x1_mirroredX, y1_mirroredX, (char*)"Mirrored X-axis");
    }
    else if (option == 2) {
        // Mirror across the Y-axis
        int x1_mirroredY = maxX - x1;
        int y1_mirroredY = y1;
        int x2_mirroredY = maxX - x2;
        int y2_mirroredY = y2;
        int x3_mirroredY = maxX - x3;
        int y3_mirroredY = y3;

        drawTriangle(x1_mirroredY, y1_mirroredY, x2_mirroredY, y2_mirroredY, x3_mirroredY, y3_mirroredY, GREEN);
        outtextxy(x1_mirroredY, y1_mirroredY, (char*)"Mirrored Y-axis");
    }
    else if (option == 3) {
        // Mirror across both X-axis and Y-axis
        int x1_mirroredXY = maxX - x1;
        int y1_mirroredXY = maxY - y1;
        int x2_mirroredXY = maxX - x2;
        int y2_mirroredXY = maxY - y2;
        int x3_mirroredXY = maxX - x3;
        int y3_mirroredXY = maxY - y3;

        drawTriangle(x1_mirroredXY, y1_mirroredXY, x2_mirroredXY, y2_mirroredXY, x3_mirroredXY, y3_mirroredXY, RED);
        outtextxy(x1_mirroredXY, y1_mirroredXY, (char*)"Mirrored both X and Y axes");
    }
    else {
        cout << "Invalid option! Exiting." << endl;
    }

    // Wait for a key press and close the graphics window
    getch();
    closegraph();

    return 0;
}

