% Main script to read an image, convert it to binary, and display the result

% altime using gray image 
img = imread('F:\MATLAB_DIP\labgray.jpg');

% Call convert2binary() function to convert the image to binary
binary_image = convert2binary(img);


figure;
subplot(1, 2, 1); 
imshow(img); 
title('Original Image');
subplot(1, 2, 2); 
imshow(binary_image); 
title('Binary Image');

% Function to convert an image to binary based on thresholding
function [binary] = convert2binary(img)

    [x, y, z] = size(img);

    % If the input is an RGB image, convert it to grayscale
    if z == 3
        img = 0.2989 * img(:,:,1) + 0.5870 * img(:,:,2) + 0.1140 * img(:,:,3); % Manual grayscale conversion
    end

    % Convert image class from 'uint8' to 'double'
    img = double(img);

    % Calculate the sum of all gray level pixel values
    total_sum = sum(img(:));

    % Calculate threshold as the average pixel value
    threshold = total_sum / (x * y);

    % Initialize the binary image matrix
    binary = zeros(x, y);

    % Apply thresholding
    for i = 1:x
        for j = 1:y
            if img(i, j) >= threshold
                binary(i, j) = 1;
            else
                binary(i, j) = 0;
            end
        end
    end
end
