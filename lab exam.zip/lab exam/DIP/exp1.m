function main()
    % Load the original RGB image
    rgb_image = imread('F:\MATLAB_DIP\rgbtaher.jpg'); 
    % Convert RGB to Grayscale
    grayscale_image = rgb_to_grayscale(rgb_image);
    % Extract each channel (Red, Green, Blue)
    R = rgb_image(:,:,1);
    G= rgb_image(:,:,2);
    B= rgb_image(:,:,3);
    % Convert Grayscale back to RGB by repeating grayscale values across channels
    grayscale_to_rgb_image = grayscale_to_rgb(grayscale_image);
    % Display the images in a 2x3 subplot layout
    figure;
    subplot(2, 3, 1);imshow(rgb_image); title('Original RGB Image');
    subplot(2, 3, 2);imshow(R); title('Red Channel');
    subplot(2, 3, 3);imshow(G);title('Green Channel');
    subplot(2, 3, 4);imshow(B);title('Blue Channel');
    subplot(2, 3, 5); imshow(grayscale_image);title('Grayscale Image');
    subplot(2, 3, 6);imshow(grayscale_to_rgb_image);title('Grayscale to RGB');
end

function grayscale_image = rgb_to_grayscale(rgb_image)
    % Get the dimensions of the RGB image
    [height, width, ~] = size(rgb_image);
    % Initialize a 2D grayscale image
    grayscale_image = zeros(height, width, 'uint8');
    % Convert each RGB pixel to grayscale
    for i = 1:height
        for j = 1:width
            R = double(rgb_image(i, j, 1));
            G = double(rgb_image(i, j, 2));
            B = double(rgb_image(i, j, 3));
            grayscale_image(i, j) = uint8(0.2989 * R + 0.5870 * G + 0.1140 * B);
        end
    end
end

function rgb_image = grayscale_to_rgb(grayscale_image)
    % Get the dimensions of the grayscale image
    [height, width] = size(grayscale_image);
    % Initialize an RGB image with 3 channels
    rgb_image = zeros(height, width, 3, 'uint8');
    % Repeat grayscale values across RGB channels
    for i = 1:height
        for j = 1:width
            gray_value = grayscale_image(i, j);
            rgb_image(i, j, :) = gray_value; % Repeat gray_value across R, G, B
        end
    end
end
