% Region Splitting and Merging for Image Segmentation
clc; clear; close all;

% Load the image
inputImage = imread('can1.jpg'); % Replace with your image path
grayImage = rgb2gray(inputImage);  % Convert to grayscale
figure, imshow(grayImage), title('Original Grayscale Image');

% Define the splitting criteria (e.g., intensity variance threshold)
varianceThreshold = 500; % Adjust as needed

% Perform recursive splitting
initialRegion = struct('image', grayImage, 'x', 1, 'y', 1, ...
    'width', size(grayImage, 2), 'height', size(grayImage, 1));
regions = split_region(initialRegion, varianceThreshold);

% Merge regions
segmentedImage = merge_regions(regions, size(grayImage));

% Display the result
figure;
imshow(segmentedImage, []), title('Segmented Image');

%% Function to recursively split a region
function regions = split_region(region, threshold)
    % Unpack region properties
    img = region.image;
    x = region.x;
    y = region.y;
    width = region.width;
    height = region.height;

    % Calculate variance
    variance = var(double(img(:)));

    % If variance exceeds threshold and region can be split
    if variance > threshold && width > 1 && height > 1
        % Split region into four sub-regions
        halfWidth = floor(width / 2);
        halfHeight = floor(height / 2);
        regions = [];

        % Define sub-regions
        subRegions = {
            struct('image', img(1:halfHeight, 1:halfWidth), 'x', x, 'y', y, ...
                'width', halfWidth, 'height', halfHeight), ...
            struct('image', img(1:halfHeight, halfWidth+1:end), 'x', x, 'y', y + halfWidth, ...
                'width', width - halfWidth, 'height', halfHeight), ...
            struct('image', img(halfHeight+1:end, 1:halfWidth), 'x', x + halfHeight, 'y', y, ...
                'width', halfWidth, 'height', height - halfHeight), ...
            struct('image', img(halfHeight+1:end, halfWidth+1:end), 'x', x + halfHeight, 'y', y + halfWidth, ...
                'width', width - halfWidth, 'height', height - halfHeight)
        };

        % Recursively split each sub-region
        for i = 1:4
            regions = [regions; split_region(subRegions{i}, threshold)];
        end
    else
        % If not splitting, keep the current region
        regions = region;
    end
end

%% Function to merge regions
function segmentedImage = merge_regions(regions, imageSize)
    segmentedImage = zeros(imageSize); % Initialize output image
    regionLabel = 1; % Initialize region label

    % Iterate over all regions
    for i = 1:length(regions)
        region = regions(i);
        x = region.x;
        y = region.y;
        width = region.width;
        height = region.height;

        % Fill the region with a unique label
        segmentedImage(x:x+height-1, y:y+width-1) = regionLabel;
        regionLabel = regionLabel + 1;
    end
end
