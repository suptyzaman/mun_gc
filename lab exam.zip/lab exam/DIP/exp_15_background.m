% Background Subtraction in MATLAB

% Read the background image
background = imread('otsu.jpg');
background = rgb2gray(background); % Convert to grayscale if it's RGB

% Read the current frame (e.g., from a video or an image)
current_frame = imread('graynegative.jpg');
current_frame = rgb2gray(current_frame); % Convert to grayscale if it's RGB

% Convert images to double precision for subtraction
background = double(background);
current_frame = double(current_frame);

% Perform background subtraction
difference = abs(current_frame - background);

% Thresholding the difference to identify foreground objects
threshold = 30; % Adjust based on your needs
foreground = difference > threshold;

% Display the original, background, and background-subtracted images
subplot(1, 3, 1);
imshow(uint8(background));
title('Background');

subplot(1, 3, 2);
imshow(uint8(current_frame));
title('Current Frame');

subplot(1, 3, 3);
imshow(foreground);
title('Background Subtracted Image');

% Optional: Save the result
imwrite(foreground, 'background_subtracted_image.jpg');
