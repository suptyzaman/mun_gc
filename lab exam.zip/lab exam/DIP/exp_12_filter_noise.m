% Load an image
originalImage = imread('pepper.jpg'); % Load your image file
if size(originalImage, 3) == 3
    originalImage = rgb2gray(originalImage); % Convert to grayscale for simplicity
end

% Resize the image for faster processing
originalImage = imresize(originalImage, [256, 256]);

% Display original image
figure;
subplot(3, 3, 1);
imshow(originalImage);
title('Original Image');

% Apply different types of noise
noisyImages = {};
noiseTypes = {'gaussian', 'salt & pepper', 'speckle'};

for i = 1:length(noiseTypes)
    noisyImages{i} = imnoise(originalImage, noiseTypes{i});
    subplot(3, 3, i+1);
    imshow(noisyImages{i});
    title([noiseTypes{i}, ' Noise']);
end

% Restore/enhance the noisy images using different filters
restoredImages = {};
filterMethods = {'Gaussian', 'Median', 'Wiener'};
PSNRValues = zeros(length(noiseTypes), length(filterMethods)); % For performance comparison

for i = 1:length(noiseTypes)
    for j = 1:length(filterMethods)
        switch filterMethods{j}
            case 'Gaussian'
                h = fspecial('gaussian', [3, 3], 0.5);
                restoredImages{i, j} = imfilter(noisyImages{i}, h, 'replicate');
            case 'Median'
                restoredImages{i, j} = medfilt2(noisyImages{i}, [3, 3]);
            case 'Wiener'
                restoredImages{i, j} = wiener2(noisyImages{i}, [5, 5]);
        end
        % Compute PSNR for performance evaluation
        PSNRValues(i, j) = psnr(restoredImages{i, j}, originalImage);
    end
end

% Display restored images and PSNR values
figure;
for i = 1:length(noiseTypes)
    for j = 1:length(filterMethods)
        subplot(length(noiseTypes), length(filterMethods), (i-1)*length(filterMethods) + j);
        imshow(restoredImages{i, j});
        title(sprintf('%s Filter\n(PSNR: %.2f dB)', filterMethods{j}, PSNRValues(i, j)));
    end
end

% Print PSNR values
disp('PSNR Values (dB):');
disp(array2table(PSNRValues, 'VariableNames', filterMethods, 'RowNames', noiseTypes));
