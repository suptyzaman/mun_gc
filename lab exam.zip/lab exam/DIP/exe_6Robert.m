% Read the input image
inputImage = imread('labgray.jpg'); % Replace with your image file
inputImage = rgb2gray(inputImage);      % Convert to grayscale if it's a color image

% Convert the image to double for computations
inputImage = double(inputImage);

% Get the size of the image
[rows, cols] = size(inputImage);

% Define Roberts kernels
Gx = [1 0; 0 -1]; % Kernel for x-direction
Gy = [0 1; -1 0]; % Kernel for y-direction

% Initialize the gradient matrices
edgeX = zeros(rows - 1, cols - 1); % Gradient in x-direction
edgeY = zeros(rows - 1, cols - 1); % Gradient in y-direction

% Apply the Roberts kernels manually
for i = 1:rows - 1
    for j = 1:cols - 1
        % Extract the 2x2 region
        region = inputImage(i:i+1, j:j+1);
        
        % Compute gradients
        edgeX(i, j) = sum(sum(region .* Gx));
        edgeY(i, j) = sum(sum(region .* Gy));
    end
end

% Compute the magnitude of the gradient
edgeMagnitude = sqrt(edgeX.^2 + edgeY.^2);

% Normalize the output to 0-255
edgeMagnitude = edgeMagnitude / max(edgeMagnitude(:)) * 255;

% Convert to uint8 for display
edgeMagnitude = uint8(edgeMagnitude);

% Display the original and edge-detected images
figure;
subplot(1, 2, 1);
imshow(uint8(inputImage));
title('Original Image');

subplot(1, 2, 2);
imshow(edgeMagnitude);
title('Edge Detected Image (Roberts Cross)');