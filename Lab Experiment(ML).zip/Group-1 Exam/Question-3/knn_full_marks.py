import numpy as np
from collections import Counter
from sklearn.metrics import accuracy_score

# Function to calculate Euclidean distance
def Euclidean_distance(x1, x2):
    return np.sqrt((x1[0] - x2[0])**2 + (x1[1] - x2[1])**2)

# KNN class
class KNN:
    def __init__(self, k=3):
        self.k = k
        
    def fit(self, X_train, Y_train):
        self.X_train = X_train
        self.Y_train = Y_train
        
    def predict(self, X_test):
        predictions = [self._predict(x) for x in X_test]
        return predictions
    
    def _predict(self, x):
        # Calculate distances from x to all training points
        distances = [Euclidean_distance(x, x_train) for x_train in self.X_train]
        # Find indices of k nearest neighbors
        indices = np.argsort(distances)[:self.k]
        # Get labels of the k nearest neighbors
        k_nearest_labels = [self.Y_train[i] for i in indices]
        # Return the most common label
        most_common = Counter(k_nearest_labels).most_common(1)
        return most_common[0][0]

# Training data
X = [4, 5, 9, 4, 3, 11, 14, 8, 10, 13]
y = [21, 19, 24, 15, 16, 25, 23, 22, 21, 22]
target = [0, 0, 1, 1, 0, 1, 0, 1, 1, 0]

# Combine X and y into input format
inp = list(zip(X, y))

# Create and train KNN model
knn = KNN(k=5)
knn.fit(inp, target)

# Evaluate accuracy
pred = knn.predict(inp)
accuracy = accuracy_score(target, pred)
print('Accuracy: ', accuracy)

# Take user input for prediction
x = int(input("Enter the x-value: "))
y = int(input("Enter the y-value: "))

# Make a single prediction
single_input = [(x, y)]
single_prediction = knn.predict(single_input)
print("Result: ", single_prediction[0])
